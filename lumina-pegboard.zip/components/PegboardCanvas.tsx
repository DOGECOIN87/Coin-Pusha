import React, { useRef, useEffect, useState } from 'react';
import { generateInitialLayout, Shape, isPointInShape, ShapeType, initializeShapeCache } from '../utils/shapeMath';

interface PegboardCanvasProps {
  gridSize?: number; // Distance between holes
  holeRadius?: number;
  enabledShapes: ShapeType[];
}

export const PegboardCanvas: React.FC<PegboardCanvasProps> = ({ 
  gridSize = 24, 
  holeRadius = 2.5,
  enabledShapes
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: window.innerWidth, height: window.innerHeight });
  const shapesRef = useRef<Shape[]>([]);
  const isDriftingRef = useRef(false);

  // Initialize shapes & cache
  useEffect(() => {
    initializeShapeCache();
    // Generate the centered word "GORBAGANA"
    shapesRef.current = generateInitialLayout(window.innerWidth, window.innerHeight);
    isDriftingRef.current = false;

    // Start drifting after 3 seconds
    const driftTimer = setTimeout(() => {
      isDriftingRef.current = true;
      shapesRef.current.forEach(shape => {
        // Assign random velocities to start the drift
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 2;
        shape.dx = Math.cos(angle) * speed;
        shape.dy = Math.sin(angle) * speed;
        shape.rotationSpeed = (Math.random() - 0.5) * 0.03;
      });
    }, 3000);

    return () => clearTimeout(driftTimer);
  }, []); // Only run once on mount

  // Handle Resize
  useEffect(() => {
    const handleResize = () => {
      const newWidth = window.innerWidth;
      const newHeight = window.innerHeight;
      
      setDimensions({ width: newWidth, height: newHeight });
      
      if (canvasRef.current) {
        canvasRef.current.width = newWidth;
        canvasRef.current.height = newHeight;
      }

      // If we haven't started drifting yet, re-center the word to match new dimensions
      if (!isDriftingRef.current) {
        shapesRef.current = generateInitialLayout(newWidth, newHeight);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false }); // Optimize for no transparency on canvas itself
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;

      // 1. Update Shapes
      shapesRef.current.forEach(shape => {
        // Only move if we have velocity (which is 0 initially)
        if (shape.dx !== 0 || shape.dy !== 0) {
          shape.x += shape.dx;
          shape.y += shape.dy;
          shape.rotation += shape.rotationSpeed;

          // Bounce off walls
          if (shape.x < -shape.size / 2 || shape.x > width + shape.size / 2) shape.dx *= -1;
          if (shape.y < -shape.size / 2 || shape.y > height + shape.size / 2) shape.dy *= -1;
          
          // Wrap around logic (optional, but bounce keeps them on screen better for this effect)
          if (shape.x < -shape.size) shape.x = width + shape.size;
          if (shape.x > width + shape.size) shape.x = -shape.size;
          if (shape.y < -shape.size) shape.y = height + shape.size;
          if (shape.y > height + shape.size) shape.y = -shape.size;
        }
      });

      // 2. Clear Background
      ctx.fillStyle = '#050505'; // Deep black/charcoal
      ctx.fillRect(0, 0, width, height);

      // 3. Draw Grid
      const cols = Math.ceil(width / gridSize);
      const rows = Math.ceil(height / gridSize);

      // Create a set for O(1) lookups inside the loop
      const enabledSet = new Set(enabledShapes);

      for (let iy = 0; iy < rows; iy++) {
        for (let ix = 0; ix < cols; ix++) {
          const px = ix * gridSize + gridSize / 2;
          const py = iy * gridSize + gridSize / 2;

          let activeShape: Shape | null = null;

          // Check against shapes
          for (const shape of shapesRef.current) {
            // Skip disabled shapes
            if (!enabledSet.has(shape.type)) continue;

            // Optimization: Bounding box check
            const boundaryRadius = shape.size * 0.75; 
            
            if (
              px < shape.x - boundaryRadius ||
              px > shape.x + boundaryRadius ||
              py < shape.y - boundaryRadius ||
              py > shape.y + boundaryRadius
            ) {
              continue;
            }

            if (isPointInShape(px, py, shape)) {
              activeShape = shape;
              break; // Found a shape, this peg is lit
            }
          }

          ctx.beginPath();
          ctx.arc(px, py, holeRadius, 0, Math.PI * 2);

          if (activeShape) {
            // LIT STATE
            ctx.fillStyle = activeShape.color;
            ctx.fill();
          } else {
            // UNLIT STATE
            ctx.fillStyle = '#1a1a1a'; // Very dark gray, barely visible
            ctx.fill();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [gridSize, holeRadius, enabledShapes]);

  return (
    <canvas
      ref={canvasRef}
      width={dimensions.width}
      height={dimensions.height}
      className="block absolute top-0 left-0 w-full h-full"
    />
  );
};