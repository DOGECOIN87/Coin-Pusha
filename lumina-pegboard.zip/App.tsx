import React, { useState } from 'react';
import { PegboardCanvas } from './components/PegboardCanvas';
import { Settings, Maximize2, Minimize2, Grid3X3, Circle, Info, Type } from 'lucide-react';
import { SHAPE_TYPES, ShapeType } from './utils/shapeMath';

export default function App() {
  const [gridSize, setGridSize] = useState(20);
  const [holeRadius, setHoleRadius] = useState(2);
  const [showControls, setShowControls] = useState(true);
  const [enabledShapes, setEnabledShapes] = useState<ShapeType[]>(SHAPE_TYPES);

  const toggleShape = (type: ShapeType) => {
    setEnabledShapes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  return (
    <div className="relative w-screen h-screen bg-black overflow-hidden font-sans text-white">
      {/* Background Canvas */}
      <PegboardCanvas 
        gridSize={gridSize} 
        holeRadius={holeRadius} 
        enabledShapes={enabledShapes}
      />

      {/* Overlay UI */}
      <div 
        className={`absolute top-6 left-6 transition-opacity duration-500 ${showControls ? 'opacity-100' : 'opacity-0 hover:opacity-100 pointer-events-none'}`}
      >
        <div className={`bg-black/40 backdrop-blur-md border border-white/10 p-6 rounded-2xl shadow-2xl max-w-sm pointer-events-auto transition-transform duration-300 ${showControls ? 'translate-y-0' : '-translate-y-4'}`}>
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-bold tracking-widest uppercase bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              Lumina Pegboard
            </h1>
            <button 
              onClick={() => setShowControls(!showControls)}
              className="text-white/50 hover:text-white transition-colors"
            >
              {showControls ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>
          </div>

          <p className="text-xs text-gray-400 mb-6 leading-relaxed">
            A simulation of a backlit pegboard. Invisible floating letters drift across the grid, revealing themselves only by illuminating the holes they pass over.
          </p>

          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-xs uppercase tracking-wider text-gray-500 font-semibold">
                <span className="flex items-center gap-2"><Grid3X3 size={14}/> Grid Density</span>
                <span>{gridSize}px</span>
              </div>
              <input
                type="range"
                min="12"
                max="50"
                step="2"
                value={gridSize}
                onChange={(e) => setGridSize(Number(e.target.value))}
                className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-cyan-500 hover:accent-cyan-400 transition-all"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs uppercase tracking-wider text-gray-500 font-semibold">
                <span className="flex items-center gap-2"><Circle size={14}/> Light Size</span>
                <span>{holeRadius}px</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="0.5"
                value={holeRadius}
                onChange={(e) => setHoleRadius(Number(e.target.value))}
                className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-purple-500 hover:accent-purple-400 transition-all"
              />
            </div>

            <div className="space-y-3">
              <div className="flex justify-between text-xs uppercase tracking-wider text-gray-500 font-semibold">
                <span className="flex items-center gap-2"><Type size={14}/> Active Letters</span>
                <span>{enabledShapes.length} / {SHAPE_TYPES.length}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {SHAPE_TYPES.map(type => (
                  <button
                    key={type}
                    onClick={() => toggleShape(type)}
                    className={`px-3 py-1.5 text-xs rounded-full font-bold transition-all border border-transparent font-mono ${
                      enabledShapes.includes(type)
                        ? 'bg-white text-black shadow-[0_0_10px_rgba(255,255,255,0.3)]'
                        : 'bg-white/5 text-gray-500 hover:bg-white/10 hover:text-gray-300 border-white/5'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-white/5 flex items-start gap-2 text-[10px] text-gray-600">
             <Info size={12} className="mt-0.5 shrink-0"/>
             <span>Only points that fall mathematically inside the active moving letters are rendered.</span>
          </div>
        </div>
      </div>

      {/* Toggle Button when controls are hidden */}
      {!showControls && (
        <button
          onClick={() => setShowControls(true)}
          className="absolute top-6 left-6 p-3 bg-black/50 border border-white/10 rounded-full text-white/50 hover:text-white backdrop-blur-md transition-all hover:scale-110 z-50 pointer-events-auto"
        >
          <Settings size={20} />
        </button>
      )}
    </div>
  );
}