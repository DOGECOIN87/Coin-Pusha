export type ShapeType = string;

// The unique letters in "GORBAGANA"
export const SHAPE_TYPES: ShapeType[] = ['A', 'B', 'G', 'N', 'O', 'R'];

export interface Shape {
  id: number;
  type: ShapeType;
  x: number;
  y: number;
  dx: number;
  dy: number;
  size: number;
  rotation: number;
  rotationSpeed: number;
  color: string;
}

const BITMAP_SIZE = 128; // Resolution of the collision mask
const bitmapCache: Record<string, Uint8Array> = {};
let isCacheInitialized = false;

/**
 * Pre-renders letters to offscreen canvases and stores their pixel data
 * to allow for fast O(1) lookups during the animation loop.
 */
export function initializeShapeCache() {
  if (isCacheInitialized) return;
  
  // We need a temporary canvas to generate bitmaps
  const canvas = document.createElement('canvas');
  canvas.width = BITMAP_SIZE;
  canvas.height = BITMAP_SIZE;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  
  if (!ctx) {
    console.error("Could not create context for shape generation");
    return;
  }

  SHAPE_TYPES.forEach(char => {
    // Clear
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, BITMAP_SIZE, BITMAP_SIZE);
    
    // Draw Letter
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    // Use a bold, blocky font for good visibility on pegboard
    ctx.font = `900 ${BITMAP_SIZE * 0.75}px "Inter", "Segoe UI", sans-serif`;
    ctx.fillText(char, BITMAP_SIZE / 2, BITMAP_SIZE / 2); 

    // Extract Pixel Data
    const imgData = ctx.getImageData(0, 0, BITMAP_SIZE, BITMAP_SIZE);
    const pixels = imgData.data; // RGBA array
    
    // Create a lightweight mask (1 byte per pixel)
    const mask = new Uint8Array(BITMAP_SIZE * BITMAP_SIZE);
    for (let i = 0; i < pixels.length; i += 4) {
      mask[i / 4] = pixels[i] > 100 ? 1 : 0;
    }
    
    bitmapCache[char] = mask;
  });

  isCacheInitialized = true;
}

export function isPointInShape(px: number, py: number, shape: Shape): boolean {
  // 1. Transform Point to Local Space
  const dx = px - shape.x;
  const dy = py - shape.y;
  
  // Inverse Rotation
  const cos = Math.cos(-shape.rotation);
  const sin = Math.sin(-shape.rotation);
  const lx = (dx * cos) - (dy * sin); 
  const ly = (dx * sin) + (dy * cos);

  // 2. Normalize to 0..1 UV space based on shape size
  const u = (lx / shape.size) + 0.5;
  const v = (ly / shape.size) + 0.5;

  // 3. Bounds check
  if (u < 0 || u >= 1 || v < 0 || v >= 1) return false;

  // 4. Sample Bitmap
  const mask = bitmapCache[shape.type];
  if (!mask) return false;

  const mapX = Math.floor(u * BITMAP_SIZE);
  const mapY = Math.floor(v * BITMAP_SIZE);
  
  const safeX = Math.max(0, Math.min(BITMAP_SIZE - 1, mapX));
  const safeY = Math.max(0, Math.min(BITMAP_SIZE - 1, mapY));

  return mask[safeY * BITMAP_SIZE + safeX] === 1;
}

export function generateInitialLayout(width: number, height: number): Shape[] {
  const word = "GORBAGANA";
  const colors = [
    '#00ffff', // Cyan
    '#ff00ff', // Magenta
    '#ffff00', // Yellow
    '#ff3333', // Red
    '#33ff33', // Green
    '#3399ff', // Blue
    '#ff9933', // Orange
  ];

  // Responsive sizing logic
  // We want the word to fit within 90% of screen width
  const count = word.length;
  const spacingFactor = 0.85; // Overlap slightly or tight spacing
  
  // Algebra: TotalWidth = size + (count - 1) * (size * spacingFactor)
  // TotalWidth approx = size * (1 + (count-1)*spacingFactor)
  // Max width available = width * 0.9
  const maxWordWidth = width * 0.9;
  const sizeByWidth = maxWordWidth / (1 + (count - 1) * spacingFactor);
  
  // Clamp size
  const size = Math.min(300, Math.max(40, sizeByWidth));
  
  const totalWidth = size * (1 + (count - 1) * spacingFactor);
  const startX = (width - totalWidth) / 2 + (size / 2); 

  return word.split('').map((char, i) => ({
    id: i,
    type: char,
    // Position in a line centered on screen
    x: startX + i * (size * spacingFactor),
    y: height / 2,
    // Start stationary
    dx: 0,
    dy: 0,
    size: size,
    rotation: 0,
    rotationSpeed: 0,
    color: colors[i % colors.length],
  }));
}