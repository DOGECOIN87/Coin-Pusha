import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { PHYSICS, DIMENSIONS, COLORS } from './constants';
import { GameConfig, GameEventCallback } from '../types';

export class GameEngine {
  // Config
  public static DEBUG_EMPTY_POOL = 0;
  public static DEBUG_AUTOPLAY = 0;
  public static DEBUG_MAX_SPEED = 0;
  public static DEBUG_COLLIDERS = 0;
  public static DEBUG_HIDE_CABINET = 0;
  public static DEBUG_POLYGONS = 0;
  public static DEBUG_CONTROLS = 1;
  public static DEBUG_FPS = 1;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private world!: RAPIER.World;
  
  // Physics Objects
  private pusherBody!: RAPIER.RigidBody;
  private coinProto!: THREE.Mesh;
  private coinInstancedMesh!: THREE.InstancedMesh;
  private coinBodies: { body: RAPIER.RigidBody; id: number }[] = [];
  
  // State
  private isInitialized = false;
  private isPaused = false;
  private requestAnimationId: number | null = null;
  private lastTime = 0;
  private accumulatedTime = 0;
  private frameCount = 0;
  private lastFpsTime = 0;
  
  private onGameStateUpdate?: GameEventCallback;
  
  // Game Variables
  private score = 0;
  private balance = 100;
  private netProfit = 0;
  private coinsCollectedRecently = 0;
  private lastCollectionTime = 0;

  // Raycasting for input
  private raycaster = new THREE.Raycaster();
  
  constructor(config: Partial<GameConfig>) {
    // Apply config overrides if needed
    if (config.debugEmptyPool) GameEngine.DEBUG_EMPTY_POOL = 1;
    if (config.debugAutoplay) GameEngine.DEBUG_AUTOPLAY = 1;
  }

  public async initialize(
    canvas: HTMLCanvasElement, 
    onUpdate: GameEventCallback
  ): Promise<void> {
    this.onGameStateUpdate = onUpdate;

    // 1. Init Physics
    await RAPIER.init();
    this.world = new RAPIER.World(PHYSICS.GRAVITY);

    // 2. Init Three.js
    this.scene = new THREE.Scene();
    // Lighter background (Deep Indigo/Twilight) so it's not a black void
    this.scene.background = new THREE.Color(0x151525); 
    // Reduced fog density so the back of the machine is visible
    this.scene.fog = new THREE.FogExp2(0x151525, 0.02);

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.camera.position.set(0, 14, 11);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ 
      canvas, 
      antialias: true,
      powerPreference: "high-performance",
      stencil: false,
      depth: true
    });
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Adjusted Tone Mapping for a brighter image
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.3;

    // 3. Lighting (Brightened)
    
    // Hemisphere Light (Sky/Ground) - Provides base visibility everywhere
    const hemiLight = new THREE.HemisphereLight(0xddeeff, 0x222233, 1.5);
    this.scene.add(hemiLight);

    // Main Spotlight - Stronger intensity
    const dirLight = new THREE.SpotLight(COLORS.LIGHT_MAIN, 1000);
    dirLight.position.set(5, 18, 5);
    dirLight.angle = Math.PI / 3;
    dirLight.penumbra = 0.2;
    dirLight.decay = 1.5;
    dirLight.distance = 60;
    dirLight.castShadow = true;
    dirLight.shadow.bias = -0.0001;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    this.scene.add(dirLight);

    // Fill Light - Softens harsh shadows
    const fillLight = new THREE.DirectionalLight(0xaaddff, 1.0);
    fillLight.position.set(-5, 10, -5);
    this.scene.add(fillLight);
    
    // Accent Light - Kept for style, but brighter
    const accentLight = new THREE.PointLight(0xff00ff, 100, 20);
    accentLight.position.set(0, 3, -2);
    this.scene.add(accentLight);

    // 4. Build Level
    this.buildStaticGeometry();
    this.buildPusher();
    this.initCoinSystem();

    // 5. Initial Pool
    if (!GameEngine.DEBUG_EMPTY_POOL) {
        this.spawnInitialCoins();
    }

    this.isInitialized = true;
    this.startLoop();
  }

  private buildStaticGeometry() {
    const pfWidth = DIMENSIONS.PLAYFIELD_WIDTH;
    const pfLength = DIMENSIONS.PLAYFIELD_LENGTH;
    const pfThickness = 1;

    // Floor Material - Brighter grey, keeps metallic feel
    const floorMat = new THREE.MeshStandardMaterial({ 
      color: COLORS.FLOOR, 
      roughness: 0.5,
      metalness: 0.6,
    });
    
    // Geometry
    const floorGeo = new THREE.BoxGeometry(pfWidth, pfThickness, pfLength);
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.position.y = -pfThickness / 2;
    floorMesh.receiveShadow = true;
    this.scene.add(floorMesh);

    // Physics
    const floorBodyDesc = RAPIER.RigidBodyDesc.fixed().setTranslation(0, -pfThickness / 2, 0);
    const floorBody = this.world.createRigidBody(floorBodyDesc);
    this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(pfWidth / 2, pfThickness / 2, pfLength / 2)
        .setFriction(PHYSICS.COIN_FRICTION), // Match coin friction for consistent sliding
        floorBody
    );

    // Walls
    const wallThickness = 0.5;
    const wallHeight = DIMENSIONS.WALL_HEIGHT;
    const wallMat = new THREE.MeshStandardMaterial({ 
        color: COLORS.CABINET,
        roughness: 0.4,
        metalness: 0.4
    });

    const createWall = (x: number, z: number, w: number, l: number) => {
        const geo = new THREE.BoxGeometry(w, wallHeight, l);
        const mesh = new THREE.Mesh(geo, wallMat);
        mesh.position.set(x, wallHeight/2, z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        if (!GameEngine.DEBUG_HIDE_CABINET) this.scene.add(mesh);

        const bodyDesc = RAPIER.RigidBodyDesc.fixed().setTranslation(x, wallHeight/2, z);
        const body = this.world.createRigidBody(bodyDesc);
        this.world.createCollider(
            RAPIER.ColliderDesc.cuboid(w/2, wallHeight/2, l/2).setFriction(0.1), // Low friction walls so coins don't climb
            body
        );
    };

    createWall(-pfWidth/2 - wallThickness/2, 0, wallThickness, pfLength);
    createWall(pfWidth/2 + wallThickness/2, 0, wallThickness, pfLength);
    createWall(0, -pfLength/2 - wallThickness/2, pfWidth + wallThickness*2, wallThickness);
    
    // Add glowing neon strips on walls - Brighter
    const stripGeo = new THREE.BoxGeometry(pfWidth, 0.05, 0.05);
    const stripMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });
    const strip = new THREE.Mesh(stripGeo, stripMat);
    strip.position.set(0, wallHeight, -pfLength/2 + 0.1);
    this.scene.add(strip);
  }

  private buildPusher() {
    const width = DIMENSIONS.PLAYFIELD_WIDTH - 0.2;
    const length = 4;
    const height = 1;

    const geo = new THREE.BoxGeometry(width, height, length);
    const mat = new THREE.MeshStandardMaterial({ 
        color: COLORS.PUSHER, 
        roughness: 0.5, 
        metalness: 0.5 
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    this.scene.add(mesh);

    const bodyDesc = RAPIER.RigidBodyDesc.kinematicPositionBased()
        .setTranslation(0, height/2 + 0.05, -DIMENSIONS.PLAYFIELD_LENGTH/2 + 2);
    this.pusherBody = this.world.createRigidBody(bodyDesc);
    this.world.createCollider(
        RAPIER.ColliderDesc.cuboid(width/2, height/2, length/2)
        .setFriction(PHYSICS.COIN_FRICTION), 
        this.pusherBody
    );

    mesh.userData = { rigidBody: this.pusherBody };
    (this.pusherBody as any).mesh = mesh;
  }

  private initCoinSystem() {
    const geometry = new THREE.CylinderGeometry(
      PHYSICS.COIN_RADIUS, 
      PHYSICS.COIN_RADIUS, 
      PHYSICS.COIN_HEIGHT, 
      32
    );
    // Highly reflective gold, but with lighter base color for visibility
    const material = new THREE.MeshStandardMaterial({ 
      color: COLORS.COIN, 
      metalness: 0.9, 
      roughness: 0.15,
      emissive: 0x442200, // Slight emissive to make them pop in shadows
      emissiveIntensity: 0.2
    });

    this.coinInstancedMesh = new THREE.InstancedMesh(geometry, material, PHYSICS.MAX_COINS);
    this.coinInstancedMesh.castShadow = true;
    this.coinInstancedMesh.receiveShadow = true;
    this.coinInstancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(this.coinInstancedMesh);

    const dummy = new THREE.Object3D();
    dummy.scale.set(0,0,0);
    dummy.updateMatrix();
    for (let i = 0; i < PHYSICS.MAX_COINS; i++) {
      this.coinInstancedMesh.setMatrixAt(i, dummy.matrix);
    }
    this.coinInstancedMesh.instanceMatrix.needsUpdate = true;
  }

  private spawnInitialCoins() {
    const count = 80;
    for (let i = 0; i < count; i++) {
        const x = (Math.random() - 0.5) * (DIMENSIONS.PLAYFIELD_WIDTH - 1);
        const z = (Math.random() - 0.5) * (DIMENSIONS.PLAYFIELD_LENGTH - 4);
        const y = 2 + Math.random() * 5;
        this.spawnCoin(x, y, z);
    }
  }

  public spawnCoin(x: number, y: number, z: number) {
    if (this.coinBodies.length >= PHYSICS.MAX_COINS) return;

    // Add slight random variation to drop position and rotation
    // This helps physics engine resolve contacts more naturally
    const randRotX = (Math.random() - 0.5) * 0.5;
    const randRotZ = (Math.random() - 0.5) * 0.5;

    const bodyDesc = RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(x, y, z)
        .setRotation({ x: randRotX, y: 0, z: randRotZ, w: 1.0 }) // Initial slight tilt
        .setLinearDamping(PHYSICS.COIN_LINEAR_DAMPING)
        .setAngularDamping(PHYSICS.COIN_ANGULAR_DAMPING)
        .setCcdEnabled(true); // Critical for thin coins
    
    const body = this.world.createRigidBody(bodyDesc);
    const collider = RAPIER.ColliderDesc.cylinder(PHYSICS.COIN_HEIGHT/2, PHYSICS.COIN_RADIUS)
        .setFriction(PHYSICS.COIN_FRICTION)
        .setRestitution(PHYSICS.COIN_RESTITUTION)
        .setDensity(PHYSICS.COIN_DENSITY); // Heavy coins
    this.world.createCollider(collider, body);

    this.coinBodies.push({ body, id: body.handle });
  }

  public dropUserCoin(normalizedX: number) {
    if (this.balance <= 0 && !GameEngine.DEBUG_AUTOPLAY) return;

    if (!GameEngine.DEBUG_AUTOPLAY) {
        this.balance--;
        this.netProfit--;
    }
    this.updateGameState();

    const z = -DIMENSIONS.PLAYFIELD_LENGTH/2 + 1;
    this.spawnCoin(normalizedX, 4, z);
  }

  public dropCoinAtRaycast(ndcX: number, ndcY: number) {
     this.raycaster.setFromCamera({ x: ndcX, y: ndcY }, this.camera);
     const dropPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -3); 
     const target = new THREE.Vector3();
     this.raycaster.ray.intersectPlane(dropPlane, target);

     const limit = DIMENSIONS.PLAYFIELD_WIDTH/2 - 0.5;
     const x = Math.max(-limit, Math.min(limit, target.x));
     
     this.dropUserCoin(x);
  }

  public bump() {
    // Apply fee
    this.balance -= 25;
    this.netProfit -= 25;
    this.updateGameState();

    // Bump physics parameters
    // We want a strong vertical pop with some chaotic lateral movement
    const verticalImpulseBase = 1.0; 
    const lateralImpulseBase = 0.5;

    this.coinBodies.forEach(({ body }) => {
        body.wakeUp(); // Ensure sleeping bodies react
        
        // Randomize direction for chaos
        const ix = (Math.random() - 0.5) * lateralImpulseBase;
        const iy = verticalImpulseBase + Math.random() * 1.5; // Always up
        const iz = (Math.random() - 0.5) * lateralImpulseBase;

        // Apply linear impulse
        body.applyImpulse({ x: ix, y: iy, z: iz }, true);

        // Apply random torque to make them spin/tumble
        body.applyTorqueImpulse({ 
            x: (Math.random() - 0.5) * 0.1, 
            y: (Math.random() - 0.5) * 0.1, 
            z: (Math.random() - 0.5) * 0.1 
        }, true);
    });
  }

  private updateGameState() {
    if (this.onGameStateUpdate) {
        this.onGameStateUpdate({
            score: this.score,
            balance: this.balance,
            netProfit: this.netProfit,
            isPaused: this.isPaused
        });
    }
  }

  public togglePause() {
      this.isPaused = !this.isPaused;
      this.updateGameState();
  }

  public reset() {
      this.score = 0;
      this.balance = 100;
      this.netProfit = 0;
      this.coinBodies.forEach(c => this.world.removeRigidBody(c.body));
      this.coinBodies = [];
      
      const dummy = new THREE.Object3D();
      dummy.scale.set(0,0,0);
      dummy.updateMatrix();
      for (let i = 0; i < PHYSICS.MAX_COINS; i++) {
        this.coinInstancedMesh.setMatrixAt(i, dummy.matrix);
      }
      this.coinInstancedMesh.instanceMatrix.needsUpdate = true;
      
      this.spawnInitialCoins();
      this.updateGameState();
  }

  private startLoop() {
    this.lastTime = performance.now();
    this.loop();
  }

  private loop = () => {
    this.requestAnimationId = requestAnimationFrame(this.loop);
    if (this.isPaused) return;

    const now = performance.now();
    const dt = (now - this.lastTime) / 1000;
    this.lastTime = now;

    this.frameCount++;
    if (now - this.lastFpsTime >= 1000) {
        if (this.onGameStateUpdate) {
            this.onGameStateUpdate({ fps: this.frameCount });
        }
        this.frameCount = 0;
        this.lastFpsTime = now;
    }

    this.accumulatedTime += dt;
    const maxSubSteps = 5; 
    let steps = 0;
    while (this.accumulatedTime >= PHYSICS.TIMESTEP && steps < maxSubSteps) {
        this.updatePhysicsLogic(now / 1000);
        this.world.step();
        this.accumulatedTime -= PHYSICS.TIMESTEP;
        steps++;
    }

    this.syncGraphics();
    this.renderer.render(this.scene, this.camera);
  }

  private updatePhysicsLogic(time: number) {
      // Use time to drive sine wave. 
      // Note: time here is wall clock. For pure determinism we'd use accumulated simulation time.
      const pusherZ = -DIMENSIONS.PLAYFIELD_LENGTH/2 + 2 + 
          Math.sin(time * (Math.PI * 2 / PHYSICS.PUSHER_PERIOD)) * PHYSICS.PUSHER_AMPLITUDE;
      
      this.pusherBody.setNextKinematicTranslation({ x: 0, y: 0.55, z: pusherZ });

      for (let i = this.coinBodies.length - 1; i >= 0; i--) {
          const body = this.coinBodies[i].body;
          const pos = body.translation();
          
          if (pos.y < -2) {
             const isWin = pos.z > DIMENSIONS.PLAYFIELD_LENGTH/2;
             if (isWin) this.handleWin();
             this.world.removeRigidBody(body);
             this.coinBodies.splice(i, 1);
          }
      }

      if (GameEngine.DEBUG_AUTOPLAY && Math.random() < 0.05) {
          this.dropUserCoin((Math.random() - 0.5) * 6);
      }
  }

  private handleWin() {
      this.score++;
      this.balance++; 
      this.netProfit++;
      
      const now = performance.now();
      if (now - this.lastCollectionTime > 5000) {
          this.coinsCollectedRecently = 0;
      }
      this.coinsCollectedRecently++;
      this.lastCollectionTime = now;
      
      if (this.coinsCollectedRecently >= 10) {
          this.balance += 5;
          this.netProfit += 5;
          this.coinsCollectedRecently = 0;
      }
      this.updateGameState();
  }

  private syncGraphics() {
      const dummy = new THREE.Object3D();
      
      const pusherPos = this.pusherBody.translation();
      const pusherMesh = (this.pusherBody as any).mesh;
      if (pusherMesh) {
          pusherMesh.position.set(pusherPos.x, pusherPos.y, pusherPos.z);
      }

      for (let i = 0; i < PHYSICS.MAX_COINS; i++) {
          if (i < this.coinBodies.length) {
              const body = this.coinBodies[i].body;
              const pos = body.translation();
              const rot = body.rotation();
              dummy.position.set(pos.x, pos.y, pos.z);
              dummy.quaternion.set(rot.x, rot.y, rot.z, rot.w);
              dummy.scale.set(1, 1, 1);
          } else {
              dummy.scale.set(0, 0, 0);
          }
          dummy.updateMatrix();
          this.coinInstancedMesh.setMatrixAt(i, dummy.matrix);
      }
      this.coinInstancedMesh.instanceMatrix.needsUpdate = true;
  }

  public resize(width: number, height: number) {
      if (this.camera && this.renderer) {
          this.camera.aspect = width / height;
          this.camera.updateProjectionMatrix();
          this.renderer.setSize(width, height);
      }
  }

  public cleanup() {
      if (this.requestAnimationId) {
          cancelAnimationFrame(this.requestAnimationId);
      }
      this.renderer.dispose();
      this.world.free();
  }
}