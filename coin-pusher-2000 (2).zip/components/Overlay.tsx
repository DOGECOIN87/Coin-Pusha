import React, { useState, useEffect } from 'react';
import { GameState } from '../types';

interface OverlayProps {
  state: GameState;
  onReset: () => void;
  onPauseToggle: () => void;
  onBump: () => void;
}

export const Overlay: React.FC<OverlayProps> = ({ state, onReset, onPauseToggle, onBump }) => {
  const [isDismissed, setIsDismissed] = useState(false);
  const [txStatus, setTxStatus] = useState<'idle' | 'signing' | 'broadcasting' | 'confirmed'>('idle');

  // Reset dismissal state when balance recovers (e.g. game reset or winning coins)
  // This satisfies: "If user closes it don't reopen it until after the next time a user reloads then runs out again"
  useEffect(() => {
    if (state.balance > 0) {
      setIsDismissed(false);
      setTxStatus('idle');
    }
  }, [state.balance]);

  const handleBumpClick = () => {
    if (txStatus !== 'idle') return;
    
    // 1. Simulate Wallet Signature
    setTxStatus('signing');
    
    setTimeout(() => {
        // 2. Simulate Network Broadcast to Treasury
        setTxStatus('broadcasting');
        
        setTimeout(() => {
            // 3. Confirmed & Execute Bump
            setTxStatus('confirmed');
            onBump();
            
            // Reset status after a moment to allow another transaction if they are still out
            setTimeout(() => {
                setTxStatus('idle');
            }, 1000);
        }, 2000); // 2s broadcast simulation
    }, 1000); // 1s signing simulation
  };

  const handleClosePopup = () => {
    setIsDismissed(true);
    setTxStatus('idle');
  };

  const showPopup = state.balance <= 0 && !state.isPaused && !isDismissed;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between overflow-hidden select-none">
      
      {/* Decorative Background Elements */}
      <div className="absolute inset-0 z-0 opacity-5 pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', backgroundSize: '30px 30px' }} 
      />
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-black/80 to-transparent pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black/90 to-transparent pointer-events-none" />

      {/* --- TOP HUD --- */}
      <div className="relative z-10 w-full p-6 flex justify-between items-start">
        
        {/* Left: Brand Identity */}
        <div className="flex flex-col justify-center select-none">
            <h1 className="text-3xl sm:text-4xl font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-600 drop-shadow-[0_0_15px_rgba(234,179,8,0.4)] font-[Orbitron]">
                COIN PUSHER <span className="text-cyan-400">2000</span>
            </h1>
            <div className="flex items-center gap-2 mt-1 opacity-70">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full shadow-[0_0_5px_lime] animate-pulse"></div>
                <span className="text-[10px] text-cyan-200 uppercase tracking-[0.3em] font-light">System Online</span>
            </div>
        </div>

        {/* Right: Economy & Wallet */}
        <div className="flex flex-col items-end gap-4 pointer-events-auto">
            
            {/* Wallet Connect Button */}
            <button className="group relative px-5 py-2 bg-slate-900/80 border border-slate-700 hover:border-purple-500/50 transition-all rounded shadow-lg overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                 <div className="flex items-center gap-3 relative z-10">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_5px_red] group-hover:bg-green-400 group-hover:shadow-[0_0_5px_lime] transition-colors"></div>
                    <span className="font-[Orbitron] text-[10px] font-bold tracking-[0.15em] text-slate-300 group-hover:text-white uppercase transition-colors">Connect Wallet</span>
                 </div>
            </button>

            {/* Stats Group - Stacked Cards */}
            <div className="flex flex-col gap-2">
                
                {/* Junk (Balance) */}
                <div className="relative group w-[200px]">
                    <div className="absolute inset-0 bg-black/60 skew-x-[-12deg] border-r-2 border-pink-500/40 group-hover:border-pink-500 transition-colors"></div>
                    <div className="relative flex flex-col items-end pr-5 py-2">
                        <div className="text-[9px] text-pink-400 uppercase tracking-[0.25em] font-bold mb-0.5 opacity-80">Junk</div>
                        <div className={`text-3xl font-black font-[Orbitron] tracking-widest drop-shadow-[0_0_10px_rgba(236,72,153,0.3)] ${state.balance <= 0 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                            {state.balance}
                        </div>
                    </div>
                </div>

                {/* Net Profit */}
                <div className="relative group w-[200px]">
                     <div className="absolute inset-0 bg-black/60 skew-x-[-12deg] border-r-2 border-yellow-500/40 group-hover:border-yellow-500 transition-colors"></div>
                     <div className="relative flex flex-col items-end pr-5 py-2">
                        <div className="text-[9px] text-yellow-400 uppercase tracking-[0.25em] font-bold mb-0.5 opacity-80">Net Profit</div>
                        <div className={`text-xl font-bold font-[Orbitron] tracking-wide ${state.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'} drop-shadow-[0_0_5px_currentColor]`}>
                            {state.netProfit > 0 ? '+' : ''}{state.netProfit}
                        </div>
                    </div>
                </div>

            </div>

        </div>
      </div>

      {/* --- CENTER: Message & Crosshair --- */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {state.isPaused ? (
             <div className="z-50 backdrop-blur-md bg-black/80 border-y border-red-500/30 py-8 px-20 shadow-[0_0_50px_rgba(0,0,0,0.8)]">
                 <div className="flex flex-col items-center">
                    <div className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 tracking-[0.05em] font-[Orbitron] drop-shadow-[0_0_20px_rgba(255,0,0,0.4)]">
                        PAUSED
                    </div>
                    <div className="mt-4 flex items-center gap-4">
                        <div className="h-[1px] w-12 bg-red-500/50"></div>
                        <div className="text-red-400 tracking-[0.4em] uppercase text-[10px] font-bold">System Halted</div>
                        <div className="h-[1px] w-12 bg-red-500/50"></div>
                    </div>
                 </div>
             </div>
          ) : (
             // Subtle Crosshair
             <div className="flex flex-col items-center justify-start h-full pt-[15vh] opacity-20">
                <div className="w-[1px] h-12 bg-white/50 mb-2"></div>
                <div className="text-[8px] uppercase tracking-[0.3em] text-white/50 font-light">Insert Coin</div>
             </div>
          )}
      </div>

      {/* --- BOTTOM HUD --- */}
      <div className="relative z-10 w-full p-8 flex items-end justify-between">
        
        {/* Controls */}
        <div className="flex gap-3 pointer-events-auto">
            <button 
                onClick={onPauseToggle}
                className="group h-12 min-w-[120px] bg-cyan-950/30 border border-cyan-500/30 hover:bg-cyan-900/50 hover:border-cyan-400 transition-all skew-x-[-15deg] backdrop-blur-sm"
            >
                <div className="skew-x-[15deg] flex items-center justify-center h-full">
                    <span className="font-[Orbitron] text-[10px] text-cyan-200 font-bold tracking-[0.2em] group-hover:text-white group-hover:drop-shadow-[0_0_5px_cyan] uppercase">
                        {state.isPaused ? 'Resume' : 'Pause'}
                    </span>
                </div>
            </button>
            
            <button 
                onClick={onReset}
                className="group h-12 min-w-[120px] bg-red-950/30 border border-red-500/30 hover:bg-red-900/50 hover:border-red-400 transition-all skew-x-[-15deg] backdrop-blur-sm"
            >
                 <div className="skew-x-[15deg] flex items-center justify-center h-full">
                    <span className="font-[Orbitron] text-[10px] text-red-200 font-bold tracking-[0.2em] group-hover:text-white group-hover:drop-shadow-[0_0_5px_red] uppercase">
                        Reset
                    </span>
                 </div>
            </button>
        </div>

        {/* Footer Info */}
        <div className="text-right pointer-events-none opacity-50 hidden sm:block">
             <div className="text-[9px] text-gray-400 uppercase tracking-widest leading-loose">
                Simulated Physics Environment <br/>
                v2.0.4 <span className="text-cyan-800 mx-2">//</span> PROD-BUILD
             </div>
        </div>
      </div>

      {/* --- POPUP: OUT OF JUNK (BUMP) --- */}
      {showPopup && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[4px] pointer-events-auto animate-in fade-in duration-300">
            <div className="relative bg-black/90 border border-red-500/60 p-1 w-[420px] shadow-[0_0_100px_rgba(220,38,38,0.25)] transform scale-100 animate-in zoom-in-95 duration-200">
                
                {/* Close Button */}
                <button 
                    onClick={handleClosePopup}
                    className="absolute top-2 right-2 z-50 p-2 text-red-500/50 hover:text-red-500 transition-colors"
                    title="Dismiss Warning"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>

                {/* Decoration: Corners */}
                <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-red-500"></div>
                <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-red-500"></div>
                <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-red-500"></div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-red-500"></div>

                <div className="border border-red-500/10 p-8 flex flex-col items-center text-center relative overflow-hidden bg-[radial-gradient(circle_at_center,_#220505_0%,_#000000_100%)]">
                    
                    {/* Animated Scanning Line */}
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-red-500/50 animate-[scan_2s_linear_infinite]"></div>

                    <div className="text-red-500 font-mono font-bold tracking-[0.3em] text-xs mb-4 animate-pulse flex items-center gap-2">
                         <span className="w-2 h-2 bg-red-500 rounded-full"></span> SYSTEM ALERT // 0xC001
                    </div>
                    
                    <h2 className="text-4xl font-black text-white font-[Orbitron] mb-2 tracking-tighter drop-shadow-[0_0_10px_rgba(255,0,0,0.5)]">
                        OUT OF JUNK
                    </h2>
                    
                    <p className="text-red-200/60 text-sm mb-8 font-[Rajdhani] leading-relaxed max-w-[80%]">
                        Resource depletion detected. Production halted. <br/>
                        <span className="text-red-400 font-bold">Initiate Treasury Transfer to trigger emergency bump.</span>
                    </p>

                    {/* Bump/Pay Button */}
                    <button 
                        onClick={handleBumpClick} 
                        disabled={txStatus !== 'idle'}
                        className={`group relative w-full h-16 transition-all clip-path-polygon mb-4 overflow-hidden shadow-[0_0_20px_rgba(220,38,38,0.2)] hover:shadow-[0_0_30px_rgba(220,38,38,0.5)] active:scale-[0.98] ${txStatus === 'idle' ? 'bg-gradient-to-r from-red-900 to-red-800 hover:from-red-600 hover:to-red-500' : 'bg-black border border-red-500/50 cursor-wait'}`}
                    >
                        {/* Button Texture */}
                        <div className="absolute inset-0 flex items-center justify-center opacity-10 bg-[linear-gradient(45deg,transparent_25%,#000_25%,#000_50%,transparent_50%,transparent_75%,#000_75%,#000_100%)] bg-[length:10px_10px]"></div>
                        
                        <div className="relative flex flex-col items-center justify-center">
                            {txStatus === 'idle' && (
                                <>
                                    <span className="font-[Orbitron] font-black text-white tracking-[0.2em] text-xl group-hover:text-white drop-shadow-md">
                                        PAY & BUMP
                                    </span>
                                    <div className="flex items-center gap-1 mt-1">
                                        <span className="text-[10px] text-red-200 font-mono bg-black/40 px-1.5 py-0.5 rounded border border-red-500/30">
                                            FEE: 25 JUNK
                                        </span>
                                    </div>
                                </>
                            )}
                            
                            {txStatus === 'signing' && (
                                <div className="flex items-center gap-3 text-red-300">
                                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    <span className="font-mono text-xs uppercase tracking-widest">Requesting Signature...</span>
                                </div>
                            )}

                            {txStatus === 'broadcasting' && (
                                <div className="flex items-center gap-3 text-yellow-300">
                                    <div className="flex gap-1">
                                        <div className="w-1.5 h-1.5 bg-yellow-300 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                        <div className="w-1.5 h-1.5 bg-yellow-300 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                                        <div className="w-1.5 h-1.5 bg-yellow-300 rounded-full animate-bounce"></div>
                                    </div>
                                    <span className="font-mono text-xs uppercase tracking-widest">Broadcasting Tx...</span>
                                </div>
                            )}

                            {txStatus === 'confirmed' && (
                                <div className="flex items-center gap-2 text-green-400">
                                     <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                     <span className="font-[Orbitron] font-bold text-lg tracking-widest">CONFIRMED</span>
                                </div>
                            )}
                        </div>
                    </button>

                    <button 
                        onClick={onReset} 
                        className="text-[10px] text-gray-500 hover:text-white transition-colors uppercase tracking-[0.2em] border-b border-transparent hover:border-white/50 pb-0.5"
                    >
                        Perform System Reset
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
};